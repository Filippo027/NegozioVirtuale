public interface IVisualizzabile
{
    void Visualizza();
}
