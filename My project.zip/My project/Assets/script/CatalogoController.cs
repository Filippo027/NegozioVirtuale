using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Collections.Generic;

public class CatalogoController : MonoBehaviour
{
    public Transform contentPanel; 
    public GameObject prodottoPrefab; 
    public TMP_InputField ricercaField;

    private List<Prodotto> prodotti;

    void Start()
    {
        prodotti = GestoreProdotti.Instance.GetProdotti();
        MostraProdotti(prodotti);
    }

    public void MostraProdotti(List<Prodotto> lista)
    {
        // Pulisce i prefab già presenti
        foreach (Transform child in contentPanel)
        {
            Destroy(child.gameObject);
        }

        // Crea i prefab per ogni prodotto
        foreach (var p in lista)
        {
            GameObject obj = Instantiate(prodottoPrefab, contentPanel);
            
            // Assicura scala e posizione corretta
            obj.transform.localScale = Vector3.one;
            obj.transform.localPosition = Vector3.zero;

            // Aggiorna testo con nome e prezzo
            TextMeshProUGUI testo = obj.GetComponentInChildren<TextMeshProUGUI>();
            if (testo != null)
                testo.text = $"{p.Nome} - {p.Prezzo}€";

            // Collega pulsante "Vedi dettagli"
            Button btn = obj.GetComponentInChildren<Button>();
            if (btn != null)
            {
                // Rimuove eventuali listener precedenti
                btn.onClick.RemoveAllListeners();
                btn.onClick.AddListener(() => VisualizzaDettagli(p));
            }
        }
    }

    public void Ricerca()
    {
        string testo = ricercaField.text;
        List<Prodotto> risultati = GestoreProdotti.Instance.RicercaPerNome(testo);
        MostraProdotti(risultati);
    }

    public void OrdinaPrezzo()
    {
        GestoreProdotti.Instance.OrdinaPerPrezzo();
        MostraProdotti(GestoreProdotti.Instance.GetProdotti());
    }

    public DettagliController dettagliController;

    void VisualizzaDettagli(Prodotto p){
        dettagliController.MostraDettagli(p);
    }

}
